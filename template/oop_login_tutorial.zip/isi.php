<?php
// Bagian users
if ($_GET['page']=='users'){
  include "users.php";
  }
